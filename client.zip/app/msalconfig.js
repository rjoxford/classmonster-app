var msalconfig = {
    clientID: "efbc893d-864d-4510-90ce-471cc7a670ca",
    redirectUri: location.origin
};
