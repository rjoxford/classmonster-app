import Ember from 'ember';

export default Ember.Component.extend({

    tagName: "td",
    classNames: "timetable-gridunit",
    classNameBindings: [ 'className', 'gridunitId' ],
    gridunitId: Ember.computed(function(){
        let time = this.get('time');
        let day = this.get('day');
        return day+time;
    }),

    // Observe a property to fill the timetable slot and prevent it from being booked over / double booked
    gridunitActivated: true,
    className: Ember.computed(function(){

        if (this.get('gridunitActivated')) {
            return "timetable-gridunit-activated";
        }
        else {
            return "timetable-gridunit-deactivated";
        }
    }),



    click(){
        let time = this.get('time');
        let day = this.get('day');
        console.log(this.get('gridunitActivated'));
        this.set('gridunitActivated', false);
        console.log(this.get('gridunitActivated'));
        this.sendAction('action', day, time);
    },

});
