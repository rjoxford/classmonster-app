import Ember from 'ember';

export default Ember.Component.extend({

    classNames: "timetable-session",


    // Calls the position action on the parent controller.
    callPosition(){
        console.log('Initiating positioning');
        var id = this.elementId;

        // Set the target destination
        let day = this.get('session.day');
        let time = this.get('session.time');
        let destination = day+time;
        console.log(destination);
        this.sendAction('position', id, destination);
    },
    // Call the controller's positioning action on the creation of the component
    didInsertElement(){
        console.log('Element Inserted');
        this.callPosition();
    },

    actions: {

    }

});
