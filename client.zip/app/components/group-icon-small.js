import Ember from 'ember';

export default Ember.Component.extend({

    classNames: ['group-icon-small', 'class-select-box'],

});
