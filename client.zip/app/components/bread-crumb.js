import Ember from 'ember';

export default Ember.Component.extend({

first: false,


// TODO set the model property as optional

});
