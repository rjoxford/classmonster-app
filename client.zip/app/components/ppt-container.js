import Ember from 'ember';

export default Ember.Component.extend({

    height: 654,
    width: 804

});
