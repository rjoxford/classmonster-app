import Ember from 'ember';

export default Ember.Route.extend({
// 
// //
// // model(params){
// //     return this.get('store').findRecord('group', params.group_id);
// // }

// model: function(){
//     return RSVP.hash({
//         group: this.get('model')
//     });
// },

});
