import Ember from 'ember';

export default Ember.Route.extend({

    // model(params){
    //     var group = this.modelFor('groups.group');
    //     var unit = this.modelFor('groups.group.gradebook.unit.');
    //     console.log("Model hook is being called");
    //     console.log(params);
    //     // console.log("Unit ID is " + params.unit_id);
    //     console.log("Group Id is " + params.group_id);
    //     return Ember.RSVP.hash({
    //         group: group,
    //         unit: unit
    //     });
    // }

});
