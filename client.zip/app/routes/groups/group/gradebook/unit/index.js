import Ember from 'ember';

export default Ember.Route.extend({

// model(params){
//     var group = this.modelFor('groups.group');
//     var unit = this.modelFor('groups.group.gradebook.unit.')
//     console.log(params.unit_id);
//     return Ember.RSVP.hash({
//         group: group
//     });
// }

});
