import Ember from 'ember';

export default Ember.Route.extend({

    // model(params){
    //     console.log(params.objective_id);
    //     return this.store.queryRecord('objective', 3);
    // }

});
